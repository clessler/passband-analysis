from setuptools import setup

setup(
    name='passband-analysis',
    version='0.0.1',
    description='functions for processing and analyzing spectra measurements',
    license='MIT',
    packages=['passband-analysis'],
    author='Tommy Alford',
    author_email='tdalford1@gmail.com',
)
